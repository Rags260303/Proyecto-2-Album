﻿using System;

namespace Proyecto_Album
{
    class Program
    {
        static Album album;

        static void marcarEstampa(string codigo)
        {
            int i = album.buscarEstampa(codigo);

            if (i >= 0)
            {
                album.estampas[i].marcar();
            }
            else
            {
                Console.WriteLine("Estampa no encontrada");
            }

        }

        static void Main(string[] args)
        {
            album = new Album();

            marcarEstampa("FWC0");
            marcarEstampa("QAT19");
            marcarEstampa("ARG17");
            marcarEstampa("GUA15");

            album.mostrarMarcadas();
        }
    }
}